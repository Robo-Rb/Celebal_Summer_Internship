# Code to display  upper triangular using '*'
n=int(input("Enter number of Rows :"))
for i in range (n,0,-1):
    print("*" * i)
