# Code to display lower triangular using '*'

n=int(input("Enter number of Rows :"))
for i in range (0,(n+1)):
    print("*"*i)
 